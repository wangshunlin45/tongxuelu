<?php
$lockFile = './install.lock'; // 也可以换成其他目录的路径，比如./install/install.lock
if (file_exists($lockFile)) {
    echo "安装锁文件存在，权限：" . substr(sprintf('%o', fileperms($lockFile)), -4);
} else {
    echo "安装锁文件不存在";
}
?>