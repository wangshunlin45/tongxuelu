<?php
$Gender=['<i class="fa fa-mars"></i> 汉子','<i class="fa fa-venus"></i> 妹子','<i class="fa fa-transgender"></i> TS/Other'];