<?php
include("Rewrite/Url.php");
include("WebAppConfig/Core.php");
include("SysConfig/SysConfig.php");
include("SysConfig/Version.php");