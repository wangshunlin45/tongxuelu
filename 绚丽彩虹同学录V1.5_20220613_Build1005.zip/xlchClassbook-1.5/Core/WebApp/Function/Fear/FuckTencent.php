<?php
if($mod == 'Index' or $mod == 'Welcome'){
	include('Core/txprotect.php');
}