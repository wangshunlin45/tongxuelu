<?php
return <<<FlandreStudio_JSON
{
    "Notice": {
        "Name": "首页公告",
        "Bewrite": "将会在班级中心显示，可以填写一些通知。"
    },
    "RegMustKnow": {
        "Name": "注册须知",
        "Bewrite": "将会在开发注册的注册页面显示，注册者必须勾选“我已阅读《注册须知》”才能够注册。"
    },
    "AboutWebsite": {
        "Name": "关于本站",
        "Bewrite": "将会在前台的“关于”页面显示。"
    }
}
FlandreStudio_JSON;
?>