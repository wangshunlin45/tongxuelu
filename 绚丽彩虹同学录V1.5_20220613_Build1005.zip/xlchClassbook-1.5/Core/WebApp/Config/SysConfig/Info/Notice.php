<?php /* 请务必不要改动这一行，否则会有安全隐患！ */ if(!defined('RootDir'))exit('Access Denied'); ?>
<span style="font-family:'Microsoft YaHei';font-size:32px;">Hello!</span> <span style="font-family:Microsoft YaHei;">欢迎您使用绚丽彩虹同学录。</span> 
<p>
	<br />
</p>
<p>
	<span style="font-family:Microsoft YaHei;">本程序开发者：<span style="color:#E53333;">悦咚 / Dark495</span>(QQ787700998)(dark495@moesys.cn)</span> 
</p>
<p>
	<span style="font-family:Microsoft YaHei;">本程序策划者：<span style="color:#337FE5;">华梦流年</span>(QQ</span><span style="font-family:Microsoft YaHei;">1991550400</span><span style="font-family:Microsoft YaHei;">)(</span><span style="font-family:Microsoft YaHei;">me@52huameng.com</span><span style="font-family:Microsoft YaHei;">)</span> 
</p>
<p>
	<span style="font-family:Microsoft YaHei;"><br />
</span> 
</p>
<p>
	<span>绚丽彩虹同学录官网：<a href="http://txl.xlch8.cn" target="_blank">txl.xlch8.cn</a></span>
</p>
<p>
	<span>绚丽彩虹同学录Ｑ群：<a href="https://jq.qq.com/?_wv=1027&k=5WEq5JF" target="_blank">589697104</a></span><span style="font-family:&quot;"><a href="https://jq.qq.com/?_wv=1027&k=5WEq5JF" target="_blank"></a></span>
</p>
<p>
	<span style="font-family:Microsoft YaHei;"><br />
</span> 
</p>
<p>
	<span style="font-family:Microsoft YaHei;">祝您使用愉快。</span> 
</p>