<?php
return <<<FlandreStudio_JSON
{
    "Ip": "localhost",
    "Port": "3306",
    "Username": "root",
    "Password": "root",
    "Database": "book",
    "QZ": "xlch"
}
FlandreStudio_JSON;
?>